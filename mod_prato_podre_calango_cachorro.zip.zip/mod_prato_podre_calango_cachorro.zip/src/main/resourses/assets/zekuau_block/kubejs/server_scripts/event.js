VAR string DeckZZX 

Class{DeckZZX}

Name: "pack.zekUau-block-1.0.0"
Description: "isso muda muito e impressiona no código"
Type = ZZXversion"0.1.2026.0.000.00"

Const plyt = {
  PlayerAlvo: player=playeralvo
  
  Void Loop();
  {
    ClickEvent("V"); 
    ClickEvent("execute")
    
    ExecuteClickEvent(
      MicrophoneAudio(Activate, OUTPUT)
      {
        mensageChat("Recording Voice")
        ClickEvent("M"); 
        ClickEvent(desActivate, MICROPHONE)
        Type = microphoneDesactivate
        MicrophoneAudio(desActivate, OUTPUT)
      }
    )
    // captura o aúdio como se fosse o Voice chat o conjunto acima
  }

  Velocity{
    components
  }
  
  Velocity.indicator("player_velocity"); {
    Position(screen, 20)
    Position(screen, 20)
  }

  Devs.element(npc_player)
  Structure(player)
  Skin(steve_playerSkin:custom)
  Name_npc: "custom:npc_steve_entity"

  // Isso faz o NPC te obedecer
  Custom(npc); 
  npcCommand(chat=0chat=name)
  NPC(NPC=objectname=npcsteve0)

  // Sistema de IA com temporizador de eliminação
  OnChatReceived(msg) {
    if (msg =msg=type=msg) {
      Api.key: "COLE_A_API_DE_IA"
      
      // Espera 4 dias do jogo (gameDays) antes de agir
      Delay(4, days=gameDays)
      
      // Executa a eliminação do jogador alvo
      Kill(kill=alvo=player)
    }
  }
}

// Configurações Globais de Idioma do Sistema
Pt_br type = "pt_brLang=language:objects"
En_us type = "Lang=language:objects:customlang"

// Módulo de Hardware e Sobrevivência
{
  // Liga uma lanterna portátil com intensidade de nível 15
  Activate(15, light)
  
  // Gatilho ativado ao pressionar a tecla L
  If (pressed=L=event)
  {
    // Verifica se o jogador morreu e força o renascimento imediato
    Verify(killed=rule=verify)
    RespawnPlayer(killed=respawn:autorespawn:customrule)
    
    // Proteção absoluta de itens: ativa o keepInventory ao reviver
    Game Command type = "game_command == /gamerule keepinventory true"
    Type = Command = true

    // Salvamento de Coordenadas: faz a pessoa renascer no lugar que morreu
    Local spawn type = "local=playerkilled=alvo=player_alvo"
    
    // Configura a string de aviso do evento
    Mensage Alvo type = "you is killed by npc"
    
    // Se o evento oculto acontecer com sucesso, registra o aviso
    If (event=killed=susseful) 
    {
      // O sistema valida que a imortalidade invisível funcionou
    }
  }
}
